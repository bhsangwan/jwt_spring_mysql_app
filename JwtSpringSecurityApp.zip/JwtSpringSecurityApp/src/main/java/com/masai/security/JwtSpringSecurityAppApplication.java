package com.masai.security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwtSpringSecurityAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(JwtSpringSecurityAppApplication.class, args);
	}

}
